# DATABYTE

Databyte Bakıda data sahəsində canlı onlayn kurslar keçirən tədris mərkəzidir: Data Analytics, Data Science, Data Engineering, Data Governance, AI Engineering. Bu sistem brendin "terminal / kod" vizual dilini tokenlərə, komponentlərə və qaydalara çevirir ki, Claude və dizaynerlər hər materialı eyni qaydalarla qursun.

Tam bələdçi: [Databyte — Brend bələdçisi 2.0](https://claude.ai/artifact/UUjhaET9VVCQAzcPUEChg1). Bu sistem həmin sənəddən qurulub; ziddiyyət olarsa, bələdçi əsasdır.

**İdeya: DATA → KOD → ŞƏBƏKƏ → KARYERA.** Tünd fon xam verilənlərdir, tək narıncı vurğu o verilənlərdən çıxan insaytdır. Mesh və şəbəkə formaları beş istiqamətin bir-birinə bağlı olduğunu göstərir. Şüarlar terminal əmri kimi qısadır və nöqtə ilə bitir.

## Dəyişməz qaydalar (hər materialdan əvvəl)

1. **Rənglər yalnız `tokens.json`-dandır.** Əsas palitra: `orange-500` #FF6033, `jet-900` #2B2A2A, `jet-500` #757474, `paper-100` #ECE8E8, `black` #111111, `white` #FFFFFF, üstəlik 4 narıncı tint. Yeni rəng, qradiyent, köhnə #D1593E yoxdur. Status üçün də yaşıl/qırmızı işlənmir: `● CANLI`, `[OK]` kimi simvol və mətn işlət.
2. **Nisbət 60 / 25 / 15:** tünd fon 60%, boz və açıq tonlar 25%, narıncı 15%. Kadrda **bir** narıncı vurğu (CTA, əsas rəqəm və ya simvol). İstisna: tam narıncı kadr (lentdə hər 5 postdan 1-i).
3. **Başlıq şrifti Cygnito Mono**, həmişə BÖYÜK HƏRFLƏ. Uzun mətn Inter. Bir materialda bir başlıq şrifti.
4. **Logo Databyte "D" simvoludur** (`assets/Logos`). Formasını, nisbətini, xətt qalınlığını dəyişmə, yenidən çəkmə, başqa logo ilə əvəzləmə.
5. **Künclər düzdür** (`radius-none`), kölgə və parlama yoxdur, xətlər nazikdir (`stroke-hairline` 1px).
6. **Kontrast:** kiçik mətn 4.5:1, 24px+ başlıq 3:1. Narıncı fonda kiçik mətn `on-accent` (#2B2A2A); ağ yalnız 24px+. Açıq fonda narıncı mətn qadağandır.

## Logo

Simvol 1:1 kvadrat qabaritlidir, diaqonalları 60°-dir (izometrik qrid). Simvolun hündürlüyü **M**, xətt qalınlığı **X ≈ M/18**.

| Fon | Simvol | Fayl |
| --- | --- | --- |
| `orange-500` | ağ | `databyte-avatar-orange.svg` (profil, tətbiq ikonu) |
| `jet-900` | ağ | `databyte-mark-white.svg` (əsas) |
| `jet-900` / `black` | narıncı | `databyte-mark-orange.svg` (vurğu variantı) |
| `paper-100` / `white` | jet | `databyte-mark-jet.svg` |

- **Boş sahə:** hər tərəfdən M/4. **Minimum:** rəqəmsal 24px (tövsiyə 32px+), çap 8mm. 16px favicon 32px fayldan kiçildilir.
- **Ad yerləşdirməsi** (ayrıca wordmark yoxdur): `DATABYTE`, `display` ailəsi, +5% hərf aralığı. Üfüqi: ad hündürlüyü M/3, simvoldan M/2 aralı, şaquli mərkəzdə. Şaquli: adın simvoldan aralığı M/4. Ad simvolla eyni rəngdə. Uzun mətndə "Databyte" yazılır.
- **Qadağan:** palitradan kənar rəng, açıq fonda narıncı simvol (2.5:1), dartmaq, əymək, fırlatmaq, kölgə, glow, kontur, 3D, simvolu dairəyə salmaq, qarışıq foto üzərində örtüksüz qoymaq.
- Profil şəkli: narıncı kvadrat, simvol kanvasın 46%-i, mərkəzdə.

## Rəng

Tünd tema (`dark`) əsasdır, açıq tema (`light`) sənəd, kitabça, sertifikatın açıq hissəsi və e-poçt üçündür. Komponentlərdə semantik tokenləri işlət: `surface`, `surface-deep`, `surface-inverse`, `ink`, `ink-muted`, `ink-inverse`, `line`, `accent`, `accent-hover`, `on-accent`, `accent-subtle`.

| Mətn | Fon | Kontrast | Qərar |
| --- | --- | --- | --- |
| `white` | `jet-900` | 14.3:1 | hər ölçü |
| `paper-100` | `jet-900` | 11.8:1 | hər ölçü; tünd fonda meta mətn |
| `orange-500` | `jet-900` | 4.75:1 | hər ölçü (14px+) |
| `orange-500` | `black` | 6.3:1 | hər ölçü |
| `jet-900` | `orange-500` | 4.75:1 | narıncı fonda standart mətn |
| `white` | `orange-500` | 3.0:1 | yalnız 24px+ başlıq və simvol |
| `jet-900` | `paper-100` | 11.8:1 | hər ölçü |
| `jet-500` | `white` | 4.7:1 | hər ölçü |
| `jet-500` | `paper-100` | 3.8:1 | yalnız 24px+ |
| `jet-500` | `jet-900` | 3.1:1 | mətn yox, yalnız xətt |
| `jet-900` | `orange-100`…`orange-400` | 11.4–5.8:1 | hər ölçü |
| `white` | `orange-400` | 2.5:1 | qadağan |
| `orange-500` | `paper-100` | 2.5:1 | mətn kimi qadağan |

Tintlər şəffaflıqla deyil, HEX ilə işlənir. Çap üçün #FF6033-ün başlanğıc CMYK-sı 0/62/80/0-dır; nümunə çapla yoxlanır.

## Tipoqrafiya

- **Cygnito Mono** (ATK Studio, pullu lisenziya): başlıq, şüar, böyük rəqəm, meta, düymə. Tək çəkisi var: CSS-də `font-synthesis: none` qoy ki, brauzer saxta qalın yaratmasın.
- **Azərbaycan hərfləri:** Cygnito Mono-da Ə/ə dəstəyi təsdiqlənməyib. Test sətri: `ƏĞİÖÜŞÇ əğıöüşç`. Ə yoxdursa, həmin materialda bütün başlıqlar **JetBrains Mono Bold** ilə yazılır (bütün 16 Azərbaycan hərfi var, OFL lisenziyası). Tək hərfi başqa şriftdən götürmək qadağandır. `display` ailəsində JetBrains Mono ehtiyat kimi artıq durur; bu sistemin önizləmələri onu göstərir.
- **Inter:** uzun mətn, kurs təsviri, UI, şəxs adları. 400 və 600 çəki, kursiv yox.
- Stillər `tokens.json`-dadır: `number`, `h1`, `h1-sm`, `h2`, `h3`, `button`, `meta`, `lead`, `body`, `body-strong`.
- **Böyük hərfi mətnin özündə yaz, CSS `text-transform: uppercase`-ə etibar etmə.** Brauzer `lang="az"` olmadan "i"-ni "I" edir ("QEYDIYYAT" alınır, düzgünü "QEYDİYYAT"), `lang="az"` ilə isə ingiliscə sözləri pozur ("ENGİNEERİNG"). Display stillərindəki hər mətn mənbədə BÖYÜK HƏRFLƏ yazılır: `QEYDİYYAT →`, `REAL LAYİHƏ`, `CANLI`, `DATA ENGINEERING`. Səhifənin `lang` atributu `az` olur.
- Başlıq sətri ≤20 simvol, sətir kəsilmələri əl ilə, defis yox. Başlıqlar sola düzlənir (mərkəz yalnız story və profil şəklində). Meta blok 2–4 sütun: `KURS / DATA SCIENCE`.
- Hosting: Inter və JetBrains Mono Google Fonts-dan yüklənir; Cygnito Mono lisenziyalı fayldan öz `@font-face`-i ilə.

## Layout və boşluq

- 8px şkala: `space-1` 4 … `space-8` 80px.
- Sosial kanvas 1080px: kənar `space-7` (64px), 6 sütun, aralıq `space-4` (24px).
- Sayt 1440px: kənar `space-8` (80px), 12 sütun, aralıq 24px. Mobil 390px.
- Çap: A3 poster kənar 15mm + 3mm bleed, 12 sütun, 5mm aralıq; A4 sertifikat kənar 20mm.
- Instagram story təhlükəsiz zona: yuxarı 250px, aşağı 300px.

## Qrafik elementlər

Hər element bir data anlayışını göstərir: mesh = şəbəkə, nöqtə = verilən, qrid = struktur, kod sətri = proses.

- **Mesh qlobus** (`MeshGlobe`): en və uzunluq xətləri `stroke-hairline`, kəsişmələrdə 3×3px nöqtələr. Narıncı fonda ağ; tünd fonda ağ xətt + narıncı nöqtə; açıq fonda jet. Kanvasın 50–75%-i, adətən kənardan kəsilir.
- **Kurs motivləri:** Data Analytics = 3D histoqram səthi; Data Science = nöqtə buludu + əyri səth; Data Engineering = laylı DAG; Data Governance = altıbucaqlı qrid qılafı içində qlobus; AI Engineering = neyron düyünlərindən kürə. Rəng hamısında eynidir.
- **Qridlər** (`FrameMarks`): izometrik 60° qrid (`stroke-grid`, `line`), künclərdə `+` kəsim işarəsi 12px, blok künclərində 6×6px vektor nöqtələri, meta şriftdə koordinat etiketi (`X:064 Y:120`), kadrda ən çox 2 etiket.
- **Terminal motivləri** (`TerminalLine`): prompt `>`, narıncı kursor `█`, status `● CANLI`, progress `[██████░░░░] 60%`. Dekor kod sətirləri `line` rəngində, oxunacaq məlumat daşımır.
- **İkonlar** (`IconRow`): 24px qrid, `stroke-icon` 1.5px, square cap, 0 radius, dolu yox, 90°/60° bucaqlar; baza Lucide. Dairəvi sıra: 48px dairə, 1px kontur, 16px aralıq, 3–5 ikon. Narıncı ikon yalnız aktiv vəziyyətdə.
- **3D fonlar:** yalnız monoxrom (qara-ağ maye xrom, parça qıvrımı). Üzərində mətn varsa `jet-900` örtüyü `overlay-photo` (0.6).

## Foto

- Ya narıncı monoxrom (Gradient Map #111111 → #FF6033 → #FFDFD6), ya tünd ton (doyum −70%, yeganə rəngli işıq narıncı). Grain 3–5%. Tam rəngli stok foto yoxdur.
- Qəhrəmanlar 20–35 yaş tələbə və gənc mütəxəssislər; ekranlarda real məzmun (dashboard, SQL, Python).
- Qadağan: gülən stok ofis, əl sıxışma, baş barmaq, ağ fonda kəsilmiş insan.
- AI şəkildə rəngi sonra Gradient Map ilə əlavə et. Promptlar bələdçinin 6-cı bölməsindədir.

## Ton və mesaj

Qısa, iddialı, terminal əmri kimi dəqiq. Şüar BÖYÜK HƏRFLƏ, nöqtə ilə bitir, nida yoxdur. Sosial mediada "sən", rəsmi mətndə (sertifikat, e-poçt) "siz". Şüarlarda "DATA", rəsmi mətndə "verilənlər". Kurs adları ingiliscə qalır. Rəqəmlər konkret ("12 HƏFTƏ"), "ən yaxşı" kimi sübutsuz iddia yox. Emoji yox (caption-da ən çox 1).

| Şüar | Harada |
| --- | --- |
| DATA YENİ KARYERANIN İLK SƏTRİDİR. | sayt hero, əsas şüar |
| GƏLƏCƏK VERİLƏNLƏRLƏ YAZILIR. | poster, cover |
| HƏR NÖQTƏ BİR İNSAYTDIR. | Data Analytics |
| HƏR SORĞU YENİ QAPI AÇIR. | SQL modulu, pulsuz dərs |
| KARYERAN İŞƏ SALINDI. | sertifikat, məzun postu |
| MAŞIN ÖYRƏNİR. SƏN İSƏ YARADIRSAN. | AI Engineering, Data Science |
| XAOSDAN QƏRARA. BİR SƏTİRLƏ. | Data Engineering, Governance |
| CANLI DƏRS. REAL DATA. YENİ SƏN. | qeydiyyat story-si, reklam |

## Komponentlər

Önizləmələr statik HTML-dir (bundle yoxdur); semantik tokenləri və tip siniflərini birbaşa işlədir. Yeni material qurarkən oradakı strukturu kopyala.

- `Button` — əsas (accent fon, on-accent mətn), ikinci (line kontur), narıncı kadr üçün tünd düymə.
- `StatCard` — böyük rəqəm + meta etiket, 1px kontur.
- `MetaLine` — çoxsütunlu meta sətri.
- `Headline` — şüar bloku: meta + H1 + lead.
- `TerminalLine` — prompt, kursor, status, progress bar.
- `CourseTag` — 5 kurs etiketi (DA, DS, DE, DG, AI).
- `IconRow` — dairəvi ikon sırası.
- `FrameMarks` — kəsim işarələri və vektor nöqtələri.
- `MeshGlobe` — data mesh qlobusu.
- `Logo` — fonlara görə simvol variantları.
- `InstagramPost` — 1080×1080 kurs elanı şablonu (bütün qaydalar bir yerdə).

## Tətbiq ölçüləri

| Material | Ölçü | Fon |
| --- | --- | --- |
| Instagram post — kurs elanı | 1080×1080 | jet |
| Instagram karusel | 1080×1350 | jet |
| Instagram story — qeydiyyat | 1080×1920 | tam narıncı |
| Kurs posteri | A3 297×420mm | jet |
| Sertifikat | A4 üfüqi 297×210mm | 99mm jet panel + paper |
| Sayt hero | 1440×800, mobil 390 | jet, nav black |
| Tələbə ID kartı | 85.6×54mm | jet önü, narıncı arxası |
| Rəqəmsal bəj | 600×600 | jet |
| Profil şəkli | 1080×1080 | narıncı |
| LinkedIn cover | 1128×191 | jet, şüar soldan 300px sonra |
| YouTube cover | 2560×1440, təhlükəsiz 1546×423 | jet |

Hər birinin dəqiq layout-u bələdçinin 8-ci bölməsindədir. Placeholder-lər kvadrat mötərizədə yazılır: `[15.01.2027]`, `[N] MƏZUN`.

## Yoxlama

- Rənglər yalnız tokenlərdən; kadrda bir narıncı vurğu.
- Logo dəyişməyib, boş sahə M/4.
- Başlıqlar Cygnito Mono (və ya qaydaya uyğun bütün materialda JetBrains Mono), BÖYÜK HƏRF, nöqtə ilə.
- Ə, Ğ, İ, Ö, Ü, Ş, Ç düzgün görünür.
- Kiçik mətn ≥4.5:1.
- [Nümunə] yazılar real məlumatla əvəz olunub.
