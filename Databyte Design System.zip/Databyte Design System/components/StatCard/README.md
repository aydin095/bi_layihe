# StatCard

Böyük rəqəm və altında meta etiketdən ibarət statistika kartı; kurs elanında, hero-da və dashboard-da işlənir.

- Kontur 1px `line`, `radius-none`, padding `space-4`, kartlar arası `space-4`.
- Rəqəm: `number` stili (sosial kanvasda 44–56px), rəng `ink`. Sırada ən vacib **bir** rəqəm `accent` ola bilər (tünd temada; açıq temada yox).
- Etiket: `meta` stili, BÖYÜK HƏRF, `ink-muted`.
- Rəqəmlər konkret olur və real məlumatdır; bilinməyən dəyər `[N]` placeholder-i ilə yazılır.
