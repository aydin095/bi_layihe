# Headline

Brendin əsas mətn bloku: meta sətri, monospace şüar və Inter-də lead.

- Meta: `meta` stili, `ink-muted`, prompt `>` ilə başlaya bilər; narıncı kursor `█` kadrda yeganə narıncı element olmadıqda işlənmir.
- Şüar: `h1` (64px desktop, 40px mobil, sosial kanvasda 72–88px), `ink`, BÖYÜK HƏRF, nöqtə ilə bitir, nida yoxdur. Sətir ≤20 simvol, kəsilmələr `<br>` ilə əl ilə qoyulur, sola düzlənir.
- Lead: `lead` stili, `ink-muted`, max en 560px, 1–2 cümlə, "sən" müraciəti (rəsmi materialda "siz").
- Şüar nümunələri README-dəki cədvəldədir; yenisini yazarkən eyni ritmi saxla: bir iddia, bir cümlə.
- Narıncı fonda şüar `white` (24px+), lead `jet-900`.
