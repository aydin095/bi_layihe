# MetaLine

Kadrın kənarında duran 2–4 sütunlu kiçik texniki mətn; redaksiya və terminal hissini verir.

- Stil `meta`: `display` ailəsi, 12px (minimum 11px, çap 7pt), hərf aralığı +8%, BÖYÜK HƏRF.
- Format: `AÇAR / DƏYƏR`, məsələn `KURS / DATA SCIENCE`, `FORMAT / CANLI ONLAYN`, `COHORT / [07]`.
- Rəng: tünd fonda `ink-muted` (#ECE8E8); açıq fonda `jet-900`. `jet-500` meta mətn üçün işlənmir.
- Yeri: kadrın yuxarı və ya aşağı zolağı, sütunlar qridə düzlənir; altında istəyə görə 1px `line` ayırıcı.
