# CourseTag

Beş kurs istiqamətinin etiketi: iki hərfli kod və ingiliscə kurs adı.

- Kodlar sabitdir: DA Data Analytics, DS Data Science, DE Data Engineering, DG Data Governance, AI AI Engineering. Kurs adları tərcümə olunmur.
- Normal: 1px `line` kontur, mətn `ink`, kod `ink-muted`, `meta` stili, hündürlük 36px, `radius-none`.
- Aktiv / seçilmiş: fon `accent`, mətn `on-accent`. Sırada yalnız bir aktiv etiket.
- Hər kursun öz mesh motivi var (README → Qrafik elementlər); etiket rəngə görə deyil, kod və motivlə fərqlənir.
