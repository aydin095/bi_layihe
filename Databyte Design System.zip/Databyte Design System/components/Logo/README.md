# Logo

Databyte "D" simvolu dəyişməz formada; yalnız fona görə rəng variantı seçilir.

- Fayllar `assets/Logos`-dadır: ağ, jet və narıncı simvol (SVG + PNG), narıncı və jet profil kvadratı. Simvolu heç vaxt yenidən çəkmə və ya kod ilə təqlid etmə; həmişə faylı `<img>` ilə işlət.
- Variant seçimi: narıncı və tünd fonda ağ; `jet-900`/`black` üzərində vurğu üçün narıncı; açıq fonda jet. Açıq fonda narıncı simvol qadağandır.
- Boş sahə M/4, minimum 24px (çap 8mm). Profil şəklində simvol kanvasın 46%-i.
- Ad yerləşdirməsi (wordmark deyil): `DATABYTE`, `display` ailəsi, +5% hərf aralığı, simvolla eyni rəng. Üfüqi: ad hündürlüyü M/3, simvoldan M/2 aralı. Şaquli: ad altda, M/4 aralı.
- Qadağan: dartmaq, fırlatmaq, kölgə, glow, kontur, qradiyent, köhnə #D1593E fon, simvolu dairəyə salmaq.
