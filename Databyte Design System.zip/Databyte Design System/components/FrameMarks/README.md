# FrameMarks

Dizaynın konstruksiyasını göstərən köməkçi qrafika: kəsim işarələri, vektor nöqtələri, koordinat etiketləri və 60° izometrik qrid.

- Kəsim işarəsi: kadrın 4 küncündə `+`, 12px, `stroke-hairline`, `ink-muted`.
- Vektor nöqtələri: əsas başlıq və ya foto blokunun 4 küncündə 6×6px kvadrat, içi `surface`, kontur 1px `ink`.
- Koordinat etiketi: `meta` stili, `ink-muted`, `X:064 Y:120`, `W:952`. Kadrda ən çox 2 etiket.
- İzometrik qrid: logodakı 60° bucağa əsaslanır, xətt `stroke-grid` (0.5px), rəng `line`, hüceyrə 2X. Fon teksturasıdır, mətnin altında zəifləşdirilir.
- Bu elementlər bəzəkdir: kadrda maksimum 2 növ işlət, əsas mesajı örtməsin.
