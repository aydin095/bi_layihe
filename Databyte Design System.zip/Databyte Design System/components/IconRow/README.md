# IconRow

Nazik xətli ikonlar və onların dairəvi sırası; kurs elanının altında və sayt footer-ində işlənir.

- İkon: 24×24 qrid, `stroke-icon` (1.5px), square cap, miter birləşmə, dolu yox, bucaqlar 90° və 60°. Baza: Lucide, bu parametrlərə uyğunlaşdırılır.
- Dəst: qlobus, kompas / 4 guşəli ulduz, verilənlər bazası, pipeline, qalxan (Governance), çip / neyron (AI), sütun diaqramı, terminal `>_`, təqvim, sertifikat, canlı yayım.
- Dairəvi sıra: hər ikon `space-6` (48px) dairədə, 1px `line` kontur, aralıq `space-3` (16px), sırada 3–5 ikon.
- Rəng: tünd fonda `ink` (ağ), açıq fonda `jet-900`. `accent` yalnız aktiv vəziyyət üçün, sırada bir dəfə.
