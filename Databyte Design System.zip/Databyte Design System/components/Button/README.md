# Button

Düz künclü CTA düyməsi; mətn `display` ailəsində, BÖYÜK HƏRFLƏ, sonunda "→".

- **Primary:** fon `accent`, mətn `on-accent` (4.75:1), hover `accent-hover`. Kadrda yalnız bir primary düymə; o, kadrın yeganə narıncı elementidir.
- **Secondary:** şəffaf fon, 1px `ink-muted` kontur, mətn `ink`.
- **Narıncı kadrda:** fon `jet-900`, mətn `white` (story, poster zolağı).
- Ölçü: hündürlük 56px (sayt), sosial kanvasda 56–110px; yan boşluq `space-5`; `radius-none`; kölgə yoxdur.
- Mətn: "QEYDİYYAT →", "KURSU SEÇ →", "LİNKƏ TOXUN →", "PULSUZ DƏRS".
