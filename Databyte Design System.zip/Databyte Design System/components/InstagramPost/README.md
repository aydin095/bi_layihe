# InstagramPost

1080×1080 kurs elanı şablonu; sistemin bütün qaydalarını bir kadrda göstərir və yeni postlar üçün başlanğıc nöqtəsidir.

- Qrid: kənar `space-7` (64px), 6 sütun, aralıq `space-4`. Fon `jet-900`.
- Yuxarı sol: ağ simvol 56px. Yuxarı sağ: `meta` 14px `paper-100`, `COHORT [07] / CANLI ONLAYN`.
- Sağ yarı: kursun mesh motivi 620px, sağ kənardan ~15% kəsilir; ağ xətt, bir narıncı düyün.
- y=300: H1 `display` 76px ağ, 3 sətir, nöqtə ilə. Altında `lead` Inter 22px `paper-100`.
- y=800: 3 `StatCard` (296×120, 1px `jet-500`). Rəqəmlər ağ.
- Aşağı sağ: CTA 300×56, `orange-500` fon, `jet-900` mətn `QEYDİYYAT →` — kadrda yeganə narıncı mətn bloku. Aşağı sol: `START / [15.01.2027]`.
- Künclərdə `+` kəsim işarəsi, başlıq blokunda vektor nöqtələri.
- Kursu dəyişəndə yalnız başlıq, lead, motiv, rəqəmlər və tarix dəyişir. `[ ]` içindəki dəyərlər placeholder-dir.
