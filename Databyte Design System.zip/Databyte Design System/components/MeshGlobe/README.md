# MeshGlobe

En və uzunluq xətlərindən qurulmuş data qlobusu; kəsişmələrdəki nöqtələr veriləndir, aralarındakı düz xətlər şəbəkə qrafıdır.

- Xətt: `stroke-hairline` (1080px kanvasda 1px, story-də 1.5px, çapda 0.35pt). Nöqtə: 3×3px–6×6px kvadrat. Şəbəkə əlaqəsi 5–8, artıq yox.
- Rəng: narıncı kadrda xətt və nöqtə `white`; tünd fonda xətt `ink`, nöqtə `accent`; açıq fonda xətt və nöqtə `jet-900`.
- Ölçü: kanvasın 50–75%-i. Adətən kadr kənarından 15% kəsilir (hərəkət hissi).
- Kurs variantları (eyni rəng qaydası): DA 3D histoqram səthi, DS nöqtə buludu + əyri səth, DE laylı DAG, DG altıbucaqlı qrid qılafında qlobus, AI neyron düyünlərindən kürə.
- Statik materialda wireframe SVG/PNG (Blender, Spline). Saytda WebGL və ya Lottie ilə yavaş fırlanma, bir dövr 30 san.
- Önizləmədəki qlobus `script` ilə orfoqrafik proyeksiyada hesablanır: 9 paralel, 10 meridian, ~20° əyilmə.
