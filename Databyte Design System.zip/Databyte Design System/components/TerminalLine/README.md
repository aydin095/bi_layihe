# TerminalLine

Terminal motivləri: prompt, kursor, status, progress bar və dekor kod sətirləri; "canlı onlayn" və "kod" ideyasını daşıyır.

- Prompt: `> ` + BÖYÜK HƏRF mətn + kursor `█` (`accent`). Saytda kursor yanıb-sönə bilər (1s addım), çapda statikdir.
- Status: `● CANLI` — nöqtə `accent`, mətn `ink-muted`. Yaşıl/qırmızı status rəngi yoxdur.
- Progress: `[████████░░] 80% DOLUB` — 10 hüceyrə, `ink` (narıncı fonda `jet-900`).
- Dekor kod: `mono` ailəsi 12–14px, rəng `line`, solunda sətir nömrəsi 01, 02. Oxunacaq məlumat daşımır, ona görə kontrast tələbi yoxdur. Nümunələr: `SELECT career FROM databyte WHERE start = 'today';`, `df.groupby('skill').mean()`, `model.fit(X_train, y_train)`, `>>> import future`.
- Fon adətən `surface-deep` (#111111) və ya `surface`.
