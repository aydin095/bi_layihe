# Logos

Databyte "D" simvolu. Fayllar mövcud logo faylından vektora çevrilib (orijinalla 99.9% üst-üstə düşür); forma dəyişdirilməyib. Orijinal JPG `databyte-logo-original.jpg` kimi saxlanılıb (fonu köhnə #D1593E-dir, yeni materiallarda işlənmir).

| Fayl | Mürəkkəb | Fon | İstifadə |
| --- | --- | --- | --- |
| `databyte-mark-white.svg` / `-2000.png` | #FFFFFF | jet-900, black, orange-500, tünd foto | əsas variant |
| `databyte-mark-jet.svg` / `-2000.png` | #2B2A2A | paper-100, white | sənəd, kitabça, e-poçt |
| `databyte-mark-orange.svg` | #FF6033 | yalnız jet-900 və black | vurğu variantı; açıq fonda qadağan |
| `databyte-avatar-orange.svg` / `-1080.png` | ağ simvol, #FF6033 kvadrat | — | profil şəkli, tətbiq ikonu (simvol kanvasın 46%-i) |
| `databyte-avatar-jet.svg` | ağ simvol, #2B2A2A kvadrat | — | tünd profil variantı |

Simvol SVG-lərinin viewBox-u 949×946-dır (1:1). Boş sahə hər tərəfdən simvol hündürlüyünün 1/4-i, minimum ölçü 24px / 8mm. SVG-ləri yalnız `<img>` ilə və ya fayl kimi işlət; rəngi CSS ilə dəyişmək olmur, uyğun rəngli faylı seç.
